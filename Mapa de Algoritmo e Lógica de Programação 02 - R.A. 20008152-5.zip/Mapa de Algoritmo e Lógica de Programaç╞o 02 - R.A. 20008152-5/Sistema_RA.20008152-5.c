#include <stdio.h>
#include <stdlib.h>
#define MAX 200
#include <locale.h>

typedef struct cadastro
{
	char titulo[50];
	char editora [50];
	char autor [50];
	int edicao, caixa, quantidade, ano, tipo;
	char isbn[13];
	
} cadastroimpresso;

void aluno();
void cadastroarquivo (cadastroimpresso cadlbr [MAX]);
void listalivros (cadastroimpresso cadlbr [MAX]);
void listarevistas (cadastroimpresso cadlbr [MAX]);
void selecionacaixa (cadastroimpresso cadlbr [MAX]);
int contadorcadastro(cadastroimpresso cadlbr [MAX]);


int main ()
{
	cadastroimpresso cadlbr [MAX]; 
	setlocale(LC_ALL, "Portuguese");

	int	menu;
	while (menu != 5)
	{
		system ("cls");
		printf ("Ola! Seja bem vindo ao organizador de livros, artigos e demais obras!");
		printf ("\nPor favor, digite o numero de uma das op��es abaixo:\n");
		printf ("1 - Cadastro.\n");
		printf ("2 - Rela��o de todos os livros cadastrados.\n");
		printf ("3 - Rela��o de todas as revistas cadastradas.\n");
		printf ("4 - Listar obras armazenadas em uma caixa espec�fica.\n");
		printf ("5 - Sair\n");
		scanf ("\n%d", &menu);
	
		switch (menu)
		{
			case 1:
				cadastroarquivo (cadlbr);
				break;
			case 2:
				printf("\n");
				listalivros (cadlbr);
				break;
			case 3:
				printf("\n");
				listarevistas (cadlbr);
				break;
			case 4:
				printf ("\n");
				selecionacaixa (cadlbr);
				break;
			case 5:
				printf ("Saindo...\n");
				break;
			default:
				printf("Op��o inv�lida, por gentileza digite um c�digo v�lido, conforme lista informada anteriormente");
				break;	
		}
	}
}
	
void aluno ()
{
		system ("cls");
		int x;
		for (x=0; x<80; x++)
			printf("-");
		printf("\nAluno: Matheus Aparecido Meletto Fontes\n");
		printf("\nR.A.: 20008152-5\n");
		printf("\nENGENHARIA DE SOFTWARE\n");
		for (x=0; x<80; x++)
			printf("-");
}	
	
void cadastroarquivo (cadastroimpresso cadlbr [MAX])
{
	aluno (); 
	int i=0, c=1, val;
	FILE * arq;
	
	arq = fopen ("biblioteca.txt", "a+");
	
	if (arq != NULL)
	{
		while (c != 0)
		{
			printf ("\nSeja bem-vindo ao cadastro das obras!\n Vamos come�ar:");
			printf ("\nA obra �:\n1-revista?\n2-livro?\n");
			val=0;
			while(val!=1) {
                fflush(stdin);
                scanf ("%d", &cadlbr[i].tipo);
                if((cadlbr[i].tipo==1) || (cadlbr[i].tipo==2)) val=1;
            }
			printf ("\nDigite o t�tulo da obra:\n");
			fflush(stdin);
			gets (cadlbr[i].titulo);
			printf ("\nDigite a edi��o:\n");
			fflush (stdin);
			scanf ("%d", &cadlbr[i].edicao);
			printf ("\nInforme o nome do autor:\n");
			fflush (stdin);
			gets (cadlbr[i].autor);
			printf ("\nInforme o nome da editora:\n");
			fflush (stdin);
			gets (cadlbr[i].editora);
			printf ("\nDigite o ano da obra:\n");
			fflush (stdin);
			scanf ("%d", &cadlbr[i].ano);
			printf ("\nInforme o ISBN:\n");
			fflush (stdin);
			gets (cadlbr[i].isbn);
			printf ("\nQual a quantidade?\n");
			fflush (stdin);
			scanf ("%d", &cadlbr[i].quantidade);
			printf ("\nEm qual caixa a obra est� armazenada?\n");
			fflush (stdin);
			scanf ("%d", &cadlbr[i].caixa);
			fwrite (&cadlbr[i], sizeof(cadastroimpresso), 1, arq);
			printf ("\n\nDeseja continuar cadastrando as obras?\n1-sim\n0-n�o\n");
			fflush (stdin);
			scanf ("%d", &c);
			}
		fclose (arq);	
	}
	else 
		{
			printf ("\nErro ao acessar o arquivo\n");
			exit (1);
		}		
}

int contadorcadastro (cadastroimpresso cadlbr [MAX])
{
	FILE * arq = fopen ("biblioteca.txt", "r");
	if (arq != NULL)
	{
		int contador = 0;
		while (1)
		{
			cadastroimpresso p;
			
			int registro = fread (&p, sizeof (cadastroimpresso), 1, arq);
			if (registro < 1)
				break;
			else
				cadlbr[contador] = p;
				contador++; 
		}
		fclose(arq);
		return contador;
	}
	else
	{
		printf ("\nErro ao ler o arquivo\n");
		exit(1);
	}
}

void listalivros (cadastroimpresso cadlbr [MAX])
{
	aluno ();
	
	int qtlivro = contadorcadastro(cadlbr);
	int i;
	
	printf ("\nSegue abaixo a rela��o dos livros cadastrados:\n");
	for (i=0;i<qtlivro;i++)
	{
		if (cadlbr[i].tipo == 2)
		{
			printf ("\nT�tulo: %s \nEditora: %s \n Edi��o: %d \nAutor: %s \nAno: %d \nISBN: %s \nQuantidade de exemplares: %d \n Caixa onde est� armazenado: %d\n", cadlbr[i].titulo, cadlbr[i].editora, cadlbr[i].edicao, cadlbr[i].autor, cadlbr[i].ano, cadlbr[i].isbn, cadlbr[i].quantidade, cadlbr[i].caixa);
		}
	}
	system ("pause");
}

void listarevistas (cadastroimpresso cadlbr [MAX])
{
	aluno ();
	
	int qtrevista = contadorcadastro(cadlbr);
	int i;
	
	printf ("\nSegue abaixo a rela��o das revistas cadastradas:\n");
	for (i=0;i<qtrevista;i++)
	{
		if (cadlbr[i].tipo == 1)
		{
			printf ("\nT�tulo: %s \nEditora: %s \n Edi��o: %d \nAutor: %s \nAno: %d \nISBN: %s \nQuantidade de exemplares: %d \n Caixa onde est� armazenado: %d", cadlbr[i].titulo, cadlbr[i].editora, cadlbr[i].edicao, cadlbr[i].autor, cadlbr[i].ano, cadlbr[i].isbn, cadlbr[i].quantidade, cadlbr[i].caixa);
		}
	}
	system ("pause");	
}

void selecionacaixa (cadastroimpresso cadlbr [MAX])
{
	aluno ();
	
	int qtcaixa = contadorcadastro (cadlbr);
	int i, j;
	printf("\nPor favor digite o n�mero da caixa que voc� quer obter a lista das obras armazenadas:\n");
	scanf ("%d", &j);
	printf ("\nSegue abaixo a rela��o das obras armazenadas na caixa %d:\n", j);
	for (i=0;i<qtcaixa;i++)
	{
		if (cadlbr[i].caixa == j)
		{
			printf ("\nT�tulo: %s \nEditora: %s \n Edi��o: %d \nAutor: %s \nAno: %d \nISBN: %s \nQuantidade de exemplares: %d \nTipo: %d", cadlbr[i].titulo, cadlbr[i].editora, cadlbr[i].edicao, cadlbr[i].autor, cadlbr[i].ano, cadlbr[i].isbn, cadlbr[i].quantidade, cadlbr[i].tipo);
		}
	}
	system ("pause");
}
